import React from "react";
import './Footer.css'

export function Footer () {
    return (
        <div class = "footer">   

            <p> © 2025 my blog </p>

        </div>
    )
}