import React from "react";
import './Header.css'

export function Header () {
    return (
        <div class = "header">
            <h1> My Blog </h1>
            <nav>
                <h2> <a href = "#home" > Home </a> </h2>
                <h2> <a href = "#about" > About </a> </h2>
                <h2> <a href = "#content" > Content </a> </h2>
            </nav>
        </div>

    )
}