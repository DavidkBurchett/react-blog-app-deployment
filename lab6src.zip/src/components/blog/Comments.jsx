import React from "react";
import './Comments.css'

export function Comments () {
    return (
        <div>
            <h2> Comments </h2>
            <textarea placeholder="Add a comment"></textarea>
            <p> <button type="submit"> Submit </button> </p>
            <h3> Existing comments </h3>
            <ul>
                <li> Comment 1 </li>
                <li> Comment 2 </li>
                <li> Comment 3 </li>
            </ul>
        </div>
    )
}