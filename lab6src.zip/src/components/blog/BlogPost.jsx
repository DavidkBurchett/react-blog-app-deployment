import React from "react"
import { Comments } from "./Comments"
import './BlogPost.css'

export function BlogPost () {

    const blogData = {title: "My first blog title", content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras vehicula eleifend libero sit amet sodales. Nunc efficitur enim a sapien dignissim, et vehicula magna bibendum. Ut eget turpis quis odio cursus tincidunt sit amet vel nulla. Maecenas a tellus non velit pulvinar efficitur. Sed sit amet suscipit mi, quis condimentum mi. Nullam consectetur ac felis id mattis. Cras blandit, dolor et laoreet ornare, mi nisl iaculis velit, id tempor dui metus in enim. Vestibulum in nisl sed urna ultricies pretium ac a mi. Duis nec metus nibh. Curabitur rutrum dictum iaculis. In hac habitasse platea dictumst. ", author: "Kyle Burchett", Date: "Oct 23, 2025"}

    return (
      <div> 
        <h1> {blogData.title} </h1>
        <p> {blogData.content} </p>
        <div class="info">
          <p> {blogData.author} </p>
          <p> {blogData.Date} </p>
        </div>

        <Comments />
      </div>
    )

  }  