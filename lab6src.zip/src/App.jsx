import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BlogPost } from './components/blog/BlogPost'
import { Header } from './components/common/header'
import { Footer } from './components/common/footer'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <Header />
      </div>
      <div class="blog">
        <BlogPost />
      </div>
      <div>
        <Footer />
      </div>
    </>
  )
}

export default App
